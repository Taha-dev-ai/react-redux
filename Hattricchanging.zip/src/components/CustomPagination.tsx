import React from 'react';
import { Pagination } from 'react-bootstrap';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { styled } from '@mui/material/styles';
import '../css-components/pagination.css'

const StyledPagination = styled(Pagination)`
  .page-item .page-link {
    color: #fff;
    background-color: transparent;
    border: none;
  }

  .page-item.active .page-link {
    // background-color: #fff;
    color: #fff;
    border-radius: 50%;
  }

  .page-item .page-link:hover {
    // background-color: rgba(255, 255, 255, 0.1);
  }

  .page-item:first-child .page-link,
  .page-item:last-child .page-link {
    border-radius: 50%;
    // background-color: rgba(255, 255, 255, 0.1);
  }
`;

const CustomPagination: React.FC<{ total: number; current: number; onPageChange: (page: number) => void; }> = ({ total, current, onPageChange }) => {
  const items = [];

  items.push(
    <Pagination.Prev className='prev' key="prev" onClick={() => onPageChange(current - 1)} disabled={current === 1}
    >
      <ArrowBackIcon />
    </Pagination.Prev>
  );

  for (let number = 1; number <= total; number++) {
    if (number === 1 || number === total || (number >= current - 1 && number <= current + 1)) {
      items.push(
        <Pagination.Item key={number} active={number === current} onClick={() => onPageChange(number)}>
          {number}
        </Pagination.Item>
      );
    } else if (number === current - 2 || number === current + 2) {
      items.push(<Pagination.Ellipsis key={`ellipsis-${number}`} />);
    }
  }

  items.push(
    <Pagination.Next className='next' key="next" onClick={() => onPageChange(current + 1)} disabled={current === total}>
      <ArrowForwardIcon />
    </Pagination.Next>
  );

  return (
    <StyledPagination>{items}</StyledPagination>
  );
};

export default CustomPagination;
