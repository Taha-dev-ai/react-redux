import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
// import DiscordIcon from '@mui/icons-material/Discord';
import footerlogo from '../image-components/Newlogo.png';
import secondimg from '../image-components/secondfotimg.png';
import { FaDiscord, FaTelegramPlane } from 'react-icons/fa';
import { FaXTwitter } from "react-icons/fa6";
import '../css-components/Fotter.css';

const Fotter: React.FC = () => {
  return (
    <footer className="footer-container">
      <Container fluid='lg'>
        <Row className='fotter'>
          <Col md={4} className='foterimg'>

          <img src={footerlogo} 
          width="200px"
          height="250px"
          alt="" 
          />
          </Col>

          <Col md={4} style={{ display: 'flex', flexDirection: 'column', }}>
          <p className='text-center fw-bold'>Follow us:</p>
          <div className="main-social">
            <div className="social-icons ">
            <a href="https://discord.com/invite/smooviephone" target="_blank" rel="noopener noreferrer">
              <FaDiscord />
            </a>
            <a href="https://t.me/smooviephonehotline" target="_blank" rel="noopener noreferrer">
            <FaTelegramPlane />
            </a>
            <a href="https://x.com/SmooviePhone" target="_blank" rel="noopener noreferrer">
            <FaXTwitter/>
            </a>
            </div> 
            </div>
          </Col>

          <Col md={4} className='foterimg'>
          <img src={secondimg} 
          width="200px"
          height="250px"
          alt="" 
          />
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Fotter;
