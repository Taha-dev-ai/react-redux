import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../css-components/CoinConvert.css"

const countryCodes = [
    "AED", "AFN", "XCD", "ALL", "AMD", "ANG", "AOA", "AQD", "ARS", "AUD",
    "AZN", "BAM", "BBD", "BDT", "XOF", "BGN", "BHD", "BIF", "BMD", "BND",
    "BOB", "BRL", "BSD", "NOK", "BWP", "BYR", "BZD", "CAD", "CDF", "XAF",
    "CHF", "CLP", "CNY", "COP", "CRC", "CUP", "CVE", "CYP", "CZK", "DJF",
    "DKK", "DOP", "DZD", "ECS", "EEK", "EGP", "ETB", "EUR", "FJD", "FKP",
    "GBP", "GEL", "GGP", "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD",
    "HNL", "HRK", "HTG", "HUF", "IDR", "ILS", "INR", "IQD", "IRR", "ISK",
    "JMD", "JOD", "JPY", "KES", "KGS", "KHR", "KMF", "KPW", "KRW", "KWD",
    "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LTL", "LVL", "LYD",
    "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRO", "MTL", "MUR",
    "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "XPF", "NGN", "NIO", "NPR",
    "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR",
    "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD",
    "SKK", "SLL", "SOS", "SRD", "STD", "SVC", "SYP", "SZL", "THB", "TJS",
    "TMT", "TND", "TOP", "TRY", "TTD", "TWD", "TZS", "UAH", "UGX", "USD",
    "UYU", "UZS", "VEF", "VND", "VUV", "YER", "ZAR", "ZMK", "ZWD"
];

const CountryExchange: React.FC = () => {
    return (
        <div className="main-CoinChange">
        <div className="CoinChange">
            <div className="container mt-5">
                <form>
                    <div className="form-group">
                        <h1 className='text-center mb-5'>CREATE  LISTING</h1>
                        <label>To:</label>
                        <div className="row">
                            <div className="col-md-6">
                                <select className="form-control">
                                    <option>Select Country</option>
                                    {countryCodes.map((code, index) => (
                                        <option key={index} value={code}>{code}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-6">
                                <input type="number" className="form-control" placeholder="Amount" />
                            </div>
                        </div>
                    </div>
                    <div className="form-group mt-3">
                        <label className='mt-5'>From:</label>
                        <div className="row">
                            <div className="col-md-6">
                                <select className="form-control">
                                    <option>Select Country</option>
                                    {countryCodes.map((code, index) => (
                                        <option key={index} value={code}>{code}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-6">
                                <input type="number" className="form-control" placeholder="Amount" />
                            </div>
                        </div>
                    </div>
                    <button className='button mt-4'>Creat</button>
                </form>
            </div>
        </div>
        </div>
    );
};

export default CountryExchange;
