import React from 'react';
import { Container, Row, Col, Nav } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';
import CryptoPunkCard from './CryptoPunkCard';
// ----------------------------------------------------------------------------------------
import post1 from '../image-components/post1.png'
// import post2 from '../image-components/post2.jpeg'
// import post3 from '../image-components/post3.jpeg'
// import post4 from '../image-components/post4.jpeg'
// import post5 from '../image-components/post5.jpeg'
// import post6 from '../image-components/post6.jpeg'
// import post7 from '../image-components/post7.jpeg'
// import post8 from '../image-components/post8.jpeg'
// -----------------------------------------------------------------------------------------
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Button, InputGroup } from 'react-bootstrap';
import SearchIcon from '@mui/icons-material/Search';
import '../css-components/Search.css';
// --------------------------------------------------------------------------------------
import { useState } from 'react';
import CustomPagination from './CustomPagination';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css-components/pagination.css'


const Post: React.FC = () => {

  // ---------------------------------------------------MainPagination------------------------

  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 32;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };



  const cards = [
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
    {
      image: post1,
      title: 'Crypto Punks Profile Image',
      cointitle: 'Coin Quantity',
      coinQuantity: 26.64,
      price: 16.7,
    },
  ];

  return (
    <div className="post">
      <Container>
        {/* ----------------------------------------------------INPUTS---------------------------------- */}
        <Row className='post-row'>
          <Col md={9}>
            <h2 className="section-header text-start mb-4">LATEST  COINS</h2>
          </Col>
          <Col md={3}>
            <InputGroup>
              <Form.Control
                type="text"
                placeholder="Tap to search from the list"
                aria-label="Search"
                className="custom-input"
              />
              <Button variant="primary" type="submit" className="custom-button">
                <SearchIcon />
                Search
              </Button>
            </InputGroup>
          </Col>
        </Row>
        <Row className="justify-content-end align-items-center mt-4 mb-5">
          <Col md={4} className="mb-3 mb-md-0">
            <Form.Select className="custom-select">
              <option>Sort By</option>
              {/* Add more options as needed */}
            </Form.Select>
          </Col>

        </Row>
        {/* -----------------------------------------------------CARD------------------------------------ */}
        <Row>
          {cards.map((card, index) => (
            <Col key={index} sm={12} md={6} lg={3}>
              <CryptoPunkCard
                image={card.image}
                title={card.title}
                cointitle={card.cointitle}
                coinQuantity={card.coinQuantity}
                price={card.price}
              />
            </Col>
          ))}
        </Row>
        {/* ---------------------------------------------------------------------------------------- */}
        <div className="main text-center my-5" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: 'white' }}>
          <CustomPagination total={totalPages} current={currentPage} onPageChange={handlePageChange} />
        </div>
        {/* -------------------------------------------------------------------------------------- */}
      </Container>
    </div>
  );
};

export default Post;
