import React, { useState } from 'react';
import { Navbar, Nav, Container, Offcanvas } from 'react-bootstrap';
import '../css-components/Navcss.css';
import { NavLink } from 'react-router-dom';
import Newlogo from '../image-components/fotimage.png';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';

const CustomNavbar: React.FC = () => {
  const [showOffcanvas, setShowOffcanvas] = useState<boolean>(false);

  const handleCloseOffcanvas = () => setShowOffcanvas(false);
  const handleShowOffcanvas = () => setShowOffcanvas(true);

  return (
    <Navbar variant="dark" expand="lg">
      <Container fluid='lg'>
        <Navbar.Brand href="#home">
          <img
            src={Newlogo}
            width="70"
            height="80"
            className="d-inline-block align-top"
            alt="Samkoo Coin logo"
          />
          <div className='text-start fw-bold m-2'>
            <h4>Over The</h4>
            {/* <p>The</p> */}
            <p>Counter</p>
          </div>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="offcanvasNavbar" onClick={handleShowOffcanvas} />
        <Navbar.Offcanvas
          id="offcanvasNavbar"
          aria-labelledby="offcanvasNavbarLabel"
          placement="end"
          show={showOffcanvas}
          onHide={handleCloseOffcanvas}
        >
          <Offcanvas.Header closeButton>
            <Offcanvas.Title id="offcanvasNavbarLabel">Menu</Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            <Nav className="center-nav mx-auto">
              <NavLink to="/" className="nav-link mx-lg-2" >Marketplace</NavLink>
              <NavLink to="" className="nav-link mx-lg-2" >Bridge</NavLink>
              <NavLink to="" className="nav-link mx-lg-2" >Tutorial Page</NavLink>
              <NavLink to="/currency-change" className="nav-link mx-lg-2" >Create listing</NavLink>
            </Nav>
            <Nav className="Navicon ms-auto">
              {/* <Nav.Link href="#search"><SearchIcon /></Nav.Link> */}
              <Nav.Link href="#wallet"><AccountBalanceWalletIcon /></Nav.Link>
            </Nav>
          </Offcanvas.Body>
        </Navbar.Offcanvas>
      </Container>
    </Navbar>
  );
}

export default CustomNavbar;
