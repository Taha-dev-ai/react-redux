import React from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import TrendingFlatIcon from '@mui/icons-material/TrendingFlat';
import '../css-components/Crypto.css';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';

type CryptoPunkCardProps = {
  image: string;
  title: string;
  cointitle: string;
  coinQuantity: number;
  price: number;
};

const CryptoPunkCard: React.FC<CryptoPunkCardProps> = ({ image, title, cointitle, coinQuantity, price }) => {
  return (
    <Card className='card-custom' >
      <Card.Img variant="top" src={image} style={{ borderRadius: '20px', padding: '10px', height: '250px' }} />
      <Card.Body>
        <Card.Title style={{ fontSize: '15px', fontWeight: '800', marginBottom: '25px' }}>{title}</Card.Title>
        <Card.Text >
          <div className='coinQuantity px-2'>
            <p>{cointitle}</p>
            <p className='coinquenty'>{coinQuantity}%</p>
          </div>
          <div className='price  px-2'>
            <div> Asking Price </div>
            <div>
                <MonetizationOnIcon />
                {price} 
            </div>
          </div>
        </Card.Text>
        <Button className='button rounded-5 px-5'>
          Buy Now
          <TrendingFlatIcon />
        </Button>
      </Card.Body>
    </Card>
  );
};

export default CryptoPunkCard;

