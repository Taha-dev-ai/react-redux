import React from 'react';
import { Container } from 'react-bootstrap';
import '../css-components/buttomfotter.css'


const bottomfotter: React.FC = () => {
  return (
    <div className='bottomfooter'>
      <Container>
        <div className="footer-bottom">
          <p>Copyright 2022 Sapphire, All Right Reserved.</p>
          <p>Privacy Policy Terms & Conditions</p>
        </div>
      </Container>
    </div>
  )
}

export default bottomfotter;