import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CustomNavbar from './components/Navbar';
import Post from './components/Post';
import Fotter from './components/Fotter';
import Bottomfotter from './components/Bottomfotter';
import CoinConvert from './components/CoinConvert';

function App() {
  return (
    <Router>
    <Routes>
      <Route path="/" element={
        <>
        <CustomNavbar/>
        <Post/> 
        <Fotter/>
        <Bottomfotter/>
        </>
        
        } />
      <Route path="/currency-change" element={
        <>
        <CustomNavbar/>
        <CoinConvert/>
        </>
      } 
        />
      
    </Routes>
  </Router>
  );
}

export default App;
